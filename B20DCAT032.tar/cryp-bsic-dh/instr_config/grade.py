import os

def read_secret(path):
    with open(path, 'r') as file:
        return file.read().strip()

def grade():
    alice_secret = read_secret("/home/alice/alice_secret.txt")
    bob_secret = read_secret("/home/bob/bob_secret.txt")

    if alice_secret == bob_secret:
        print("Success: Khóa bí mật khớp nhau.")
        return True
    else:
        print("Failure: Khóa bí mật không khớp.")
        return False

if __name__ == "__main__":
    grade()

