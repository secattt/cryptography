#include<bits/stdc++.h>
#include <cstring>
#include <fstream>
#include <string>
using namespace std;

typedef long long int ll;

// Các khai báo biến và hàm như trong đoạn mã của bạn
// ...

int main()
{
    // In dòng chữ yêu cầu
    cout << "Hãy viết giải thuật thám mã số e nhỏ trên RSA bằng định lý số dư Trung Hoa" << endl;

    return 0;
}

